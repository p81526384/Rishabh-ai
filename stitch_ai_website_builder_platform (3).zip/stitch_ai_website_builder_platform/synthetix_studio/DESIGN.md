---
name: Synthetix Studio
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#ccc3d8'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#958da1'
  outline-variant: '#4a4455'
  surface-tint: '#d2bbff'
  primary: '#d2bbff'
  on-primary: '#3f008e'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#732ee4'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#007650'
  on-tertiary-container: '#76ffc2'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-code-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.02em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-badge:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
  space-2xl: 3.5rem
---

## Brand & Style

This design system embodies the tension between raw computational precision and frictionless creative velocity. Tailored for software engineers, product designers, and technical founders building at the speed of thought, the identity merges developer-centric utility with a high-octane cyberpunk minimalism.

### Key Pillars
- **Radical Velocity:** Interfaces react instantaneously with micro-interactions, subtle luminous states, and zero visual friction.
- **Uncompromising Openness:** The platform is grounded in absolute accessibility—unlimited generation, community-driven forkability, and seamless zero-configuration deployments. Visual elements must communicate autonomy and empowerment rather than paywalls or gated constraints.
- **Instrument-Grade Clarity:** The UI feels like an IDE from 2035: deep, atmospheric surfaces, crisp micro-borders, laser-sharp monospaced data readouts, and vivid synthetic luminescence that directs attention strictly to code and canvas.

## Colors

The palette operates in a default hyper-dark spectrum, utilizing deep slate and obsidian undertones to allow luminous electric accents to cut through with tactical precision.

### Color Architecture
- **Primary (`#7C3AED` - Electric Violet):** Signifies primary action vectors, neural compilation states, and core execution triggers.
- **Secondary (`#06B6D4` - Cyber Cyan):** Represents live connections, instant previews, telemetry streams, and deployment pathways.
- **Tertiary (`#10B981` - Kinetic Mint):** Marks successful continuous builds, verified status nodes, and community forks.
- **Surface Hierarchy:**
  - Base Canvas: `#0B0F19` (Obsidian Deep)
  - Surface Low: `#111827` (Charcoal Slate)
  - Surface Mid: `#182234` (Elevated Panel)
  - Surface High: `#1F2E45` (Interactive Hover/Active)
- **Border & Grid Infrastructure:** Outlines rely on translucent neutral overlays (`rgba(255, 255, 255, 0.08)` to `rgba(255, 255, 255, 0.15)`), shifting to focused neon radiance (`rgba(124, 58, 237, 0.45)` or `rgba(6, 182, 212, 0.45)`) on engagement.

## Typography

The typographic hierarchy balances structural architecture with machine-readable telemetry:
- **Headlines (Space Grotesk):** Provides technological personality, sharp angles, and progressive editorial character for platform claims and section markers.
- **Body & Controls (Geist):** Delivers ultra-clean neutral legibility across high-density sidebars, code comments, system notifications, and canvas controllers.
- **Telemetry & Metadata (JetBrains Mono):** Anchors command prompts, commit hashes, generation counters, live terminal output, and keyboard shortcut tokens.

## Layout & Spacing

The layout operates on an infinite-canvas and workspace paradigm:
- **App Workspace:** A 3-pane flexible layout spanning code editor/chat bar (docked 320px–420px), central reactive viewport (fluid stretch), and inspector panel (dockable 280px).
- **Public/Community Hub:** Standard 12-column fluid grid system bounded at `1440px` with `1.25rem` gutters on desktop, collapsing to a single-column stacked layout below `768px`.
- **Rhythm:** Spacing follows an exact 4px sub-grid with structural component gaps governed by `space-sm` (8px) for related controls, `space-md` (12px) for form blocks, and `space-xl` (32px) for card separations.

## Elevation & Depth

Depth in this design system avoids skeuomorphic dropshadows in favor of **luminous backdrops, directional neon radiants, and translucent layering**:

- **Layer 0 (Canvas Base):** Ground `#0B0F19` with a subtle micro-dot or scanline SVG grid pattern at 4% opacity.
- **Layer 1 (Panels & Shells):** Background `#111827` at 85% opacity with `backdrop-filter: blur(16px)` and a continuous 1px outline: `rgba(255, 255, 255, 0.08)`.
- **Layer 2 (Floating Modals & Code Drawers):** Background `#182234` with dual glow:
  - Subtle shadow: `0 8px 32px 0 rgba(0, 0, 0, 0.65)`
  - Edge glow: `0 0 0 1px rgba(124, 58, 237, 0.25), 0 0 16px -4px rgba(124, 58, 237, 0.3)`
- **Layer 3 (Live Output & Viewport Focus):** Cyan halo highlights (`rgba(6, 182, 212, 0.4)`) reserved strictly for active generation nodes, real-time code injection frames, and instantaneous deploy triggers.

## Shapes

The design system maintains a **compact, technical radius profile (Soft - Level 1)** to reinforce surgical precision:
- Primary container panels, code blocks, and editor frames use `0.375rem` (6px) or `0.5rem` (8px) corners.
- Interactive controls (inputs, buttons, chip selectors) adhere strictly to `0.25rem` (4px) to `0.375rem` (6px).
- **Pill Exception:** Status indicators, git branch tags, open-source badges, and "Direct Deploy" node pills utilize full circular border-radii (`9999px`) to create high-contrast geometric anchors against rectilinear editor frames.

## Components

### Buttons
- **Primary Generator (`Run / Deploy`):** Electric violet background (`#7C3AED`) with a white label, subtle inset top highlight (`inset 0 1px 0 rgba(255,255,255,0.2)`), and an outer neon bloom on hover (`box-shadow: 0 0 20px rgba(124, 58, 237, 0.45)`).
- **Secondary / Action (`Fork / Export`):** Background `#111827`, border `1px solid rgba(255, 255, 255, 0.12)`, hover state transitions to cyan text (`#06B6D4`) and cyan border (`rgba(6, 182, 212, 0.4)`).
- **Ghost Utility:** Borderless with `JetBrains Mono` labels and interactive icon glyphs; background activates to `rgba(255, 255, 255, 0.06)` on hover.

### Prompt Bar & AI Input
- Heavy frosted glass chassis (`#111827` at 90% opacity with 20px blur).
- Outer perimeter features a multi-color reactive gradient border (Electric Violet transitioning into Cyber Cyan).
- Integrated quick-action tags (e.g., `+ Add Tailwind`, `+ Realtime Database`, `+ Auth Boilerplate`) embedded as clickable micro-pills along the bottom edge.

### Terminal & Code Cards
- Windows styled with header metadata pills (e.g., `bash`, `server.ts`, `34ms compilation time`).
- Syntax highlighted with neon greens, soft ambers, and electric cyans on `#0B0F19`.
- Integrated instant "Fork to Sandpack" and "Direct Deploy" actions on top-right toolbars.

### Open Community & Unlimited Access Chips
- High-visibility status tags highlighting zero gatekeeping:
  - `Unlimited Generations`: Violet glow badge with infinity symbol (`∞`).
  - `100% Open Access`: Cyan border with live pulse beacon dot.
  - `Community Sandbox`: Pill badge linking directly to inspectable AST and source trees.

### Checkboxes, Toggles & Radios
- Square micro-radii (3px). Unchecked: `1px solid rgba(255,255,255,0.2)` over transparent background. Checked: `#7C3AED` with an SVG micro-check in pure white.
- Toggles feature a sliding pill with an active glow indicator.